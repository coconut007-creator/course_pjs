#include "philosopher.h"

void *philosopher(void *philosopherNumber) {
	int i = (int)philosopherNumber;
	while (1) {
		/*Your code here*/
		//printf("unimplemented yet\n");
		think(i);
		printf("Philosopher %d is hungry\n", i);
		pickUp(i);
		eat(i);
		putDown(i);
	}
}

void think(int philosopherNumber) {
	int sleepTime = rand() % 3 + 1;
	printf("Philosopher %d will think for %d seconds\n", philosopherNumber, sleepTime);
	sleep(sleepTime);
}

void pickUp(int philosopherNumber) {
	// request chopsticks
	int left = philosopherNumber;
	int right = (philosopherNumber + 1) % NUMBER_OF_PHILOSOPHERS;
	if(philosopherNumber%2){
		pthread_mutex_lock(&chopsticks[left]);
		printf("Philosopher %d picks up chopsticks %d.\n", philosopherNumber, left);
		pthread_mutex_lock(&chopsticks[right]);
		printf("Philosopher %d picks up chopsticks %d.\n", philosopherNumber, right);
	}
	else{
		pthread_mutex_lock(&chopsticks[right]);
		printf("Philosopher %d picks up chopsticks %d.\n", philosopherNumber, right);
		pthread_mutex_lock(&chopsticks[left]);
		printf("Philosopher %d picks up chopsticks %d.\n", philosopherNumber, left);
	}
    /*Your code here*/
	
}

void eat(int philosopherNumber) {
	int eatTime = rand() % 3 + 1;
	printf("Philosopher %d will eat for %d seconds\n", philosopherNumber, eatTime);
	sleep(eatTime);
}

void putDown(int philosopherNumber) {
	// release chopsticks
	int left = philosopherNumber;
	int right = (philosopherNumber + 1) % NUMBER_OF_PHILOSOPHERS;
	if(philosopherNumber%2){
		pthread_mutex_unlock(&chopsticks[right]);
		printf("Philosopher %d puts down chopsticks %d.\n", philosopherNumber, right);
		pthread_mutex_unlock(&chopsticks[left]);
		printf("Philosopher %d puts down chopsticks %d.\n", philosopherNumber, left);
	}
	else{
		pthread_mutex_unlock(&chopsticks[left]);
		printf("Philosopher %d puts down chopsticks %d.\n", philosopherNumber, left);
		pthread_mutex_unlock(&chopsticks[right]);
		printf("Philosopher %d puts down chopsticks %d.\n", philosopherNumber, right);
	}
    /*Your code here*/
}
