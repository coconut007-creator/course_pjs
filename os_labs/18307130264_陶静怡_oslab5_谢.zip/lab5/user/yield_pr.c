#include <inc/lib.h>

void
umain(int argc, char **argv)
{
	//cprintf("enter yield\n");
	int i;
    cprintf("Hello, I am environment %08x. Priority: %d\n", thisenv->env_id, thisenv->pr);
	//cprintf("pr:%d\n", thisenv->pr);
	for (i = 0; i < 3; i++) {
		sys_pr_yield();
		cprintf("Back in environment %08x, iteration %d.\n",
			thisenv->env_id, i);
	}
	cprintf("All done in environment %08x.\n", thisenv->env_id);
}