# load the package
from question import *
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import TfidfVectorizer
import jieba


class Question_classify():
    def __init__(self):
        self.x, self.y = self.load_data()
        self.model = self.train_NB()

    def load_data(self):
        x = []
        y = []
        train = []
        questions = [q0, q1, q2, q3, q4, q5, q6, q7]

        for q in questions:
            label = questions.index(q)
            for line in q:
                word_list = list(jieba.cut(str(line).strip()))
                x.append(" ".join(word_list))
                y.append(label)
        return x, y

    def train_NB(self):
        print(self.x)
        print(self.y)
        x_train, y_train = self.x, self.y
        self.tv = TfidfVectorizer()
        train_data = self.tv.fit_transform(x_train).toarray()
        clf = MultinomialNB(alpha=0.01)
        clf.fit(train_data, y_train)

        return clf

    def predict(self, question):
        question = [" ".join(list(jieba.cut(question)))]
        test_data = self.tv.transform(question).toarray()
        predict = self.model.predict(test_data)[0]
        return predict


if __name__ == "__main__":
    qc = Question_classify()
    print(qc.predict("旦苑有什么吃的"))