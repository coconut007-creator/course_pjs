#!/usr/bin/python3

import pymysql

class Query():
    def __init__(self):
        # 打开数据库连接
        self.db = pymysql.connect("localhost", "root", "zunaiJKS", "dishes")
        # 使用 cursor() 方法创建一个游标对象 cursor
        self.cursor = self.db.cursor()

    def run(self, sql, v):
        try:
            # 执行SQL语句
            self.cursor.execute(sql,v)
            # 获取所有记录列表
            results = self.cursor.fetchall()
        except:
            print("Error: unable to fetch data")

        return results


if __name__ == "__main__":
    sql = Query()
    #dish_title = '双皮奶'
    #res = sql.run("select dish.name from dish,restaurant where restaurant.name=%s and dish.rid = restaurant.rid", '南食')
    #res = sql.run("select review from dish where name=%s", '双皮奶')[0]
    #res = sql.run("select name from restaurant where campus=%s", '南区')
    res = sql.run("select dish.name from dish,restaurant where restaurant.name=%s and dish.rid=restaurant.rid", '南食')
    print(res)