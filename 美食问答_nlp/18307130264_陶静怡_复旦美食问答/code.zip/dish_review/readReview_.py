import csv 
import jieba
from wordcloud import WordCloud

neg , pos = "",""
csv_file = open("review.csv")
csv_reader_lines = csv.reader(csv_file)
i = 0
pos_count ,neg_count = 0,0

for line in csv_reader_lines:
   content, label = line[0] , line[1]
   if line[1] == '0':
      words = jieba.cut(content)
      neg += ' '.join(jieba.cut(content))
      neg_count += 1
   if line[1] == '1':
      pos += ' '.join(jieba.cut(content))
      pos_count += 1

with open("pos.txt", "w", encoding='utf-8') as f:
   f.write(pos)

with open("neg.txt", "w", encoding='utf-8') as f:
   f.write(neg)



#Word Cloud Analysis 词云分析


font_ = "SimHei.ttf"

wordCloud = WordCloud(font_path = font_,background_color='white',max_font_size=60).generate(pos)
img = wordCloud.to_image()
img.show()
img.save("positive_reviews.jpg")

wordCloud = WordCloud(font_path = font_,background_color='white',max_font_size=60).generate(neg)
img = wordCloud.to_image()
img.show()
img.save("negative_reviews.jpg")


print(pos_count,neg_count)


