from snownlp import sentiment
from snownlp import SnowNLP
import os

if __name__ == "__main__":
    sentiment.train('neg.txt','pos.txt')
    sentiment.save('sentiment.marshal')