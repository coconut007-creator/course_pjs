from consql import Query
import re
import os
from snownlp import sentiment

questions = {
    0: "nm 味道",  # 菜品评价
    1: "rr 菜",  # 某食堂的主要菜品
    2: "ut 食堂",  # 某校区的食堂
    3: "rr 人均",  # 某食堂的人均
    4: "rr 评价",  # 某食堂的评分
    5: "ut 好吃的菜",  # 某个校区的味道不错的菜
    6: "rr 好吃的菜",  # 某个食堂的味道不错的菜
    7: "sst 菜",  # 某菜系有什么菜
}

# Load the pretrained sentiment classification model

data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sentiment.marshal')
sentiment.load(data_path)


class QuestionTemplate():
    def __init__(self):
        self.q_template_dict = {
            0: self.get_dish_rating,
            1: self.get_res_dish,
            2: self.get_campus_res,
            3: self.get_cost_res,
            4: self.get_score_res,
            5: self.get_gooddisk_campus,
            6: self.get_gooddisk_res,
            7: self.get_dish_type,
        }
        self.query = Query()

    def get_question_answer(self, question, template):

        assert len(str(template).strip().split("\t")) == 2
        template_id, template_str = int(str(template).strip().split("\t")[0]), str(template).strip().split('\t')[1]
        self.template_id = template_id
        self.template_str2list = str(template_str).split()

        question_word, question_flag = [], []

        for one in question:
            word, flag = one.split("/")
            question_word.append(str(word).strip())
            question_flag.append(str(flag).strip())

        assert len(question_word) == len(question_flag)

        self.question_word = question_word
        self.question_flag = question_flag
        self.raw_question = question

        answer = self.q_template_dict[template_id]()

        return answer

    # Helper Functions 
    #   Given a type name, return the corresponding word which is tagged as that type
    def get_name(self, type_str):

        count = self.question_flag.count(type_str)
        if count == 1:
            index = self.question_flag.index(type_str)
            return self.question_word[index]
        else:
            results = []
            for i, flag in enumerate(self.question_flag):
                if flag == str(type_str):
                    results.append(self.question_word[i])
            return results

    # Question 0 - 对菜品的评价
    def get_dish_rating(self):
        dish_title = self.get_name("nm")
        sql = "select review from dish where name=%s"
        answer = self.query.run(sql, dish_title)[0][0]
        res = dish_title + "评价:" + str(answer) + "~"
        return res

    # Question 1 - 某食堂的主要菜品
    def get_res_dish(self):
        restaurant = self.get_name("rr")
        sql = "select dish.name from dish,restaurant where restaurant.name=%s and dish.rid = restaurant.rid"
        ans_list = self.query.run(sql, restaurant)
        list = []
        for ans in ans_list:
            list += ans
        ans = "、".join(list)
        res = restaurant + "的菜有：" + ans + "..."
        return res

    # Question 2 - 某校区有哪些食堂
    def get_campus_res(self):
        campus = self.get_name("ut")
        sql = "select name from restaurant where campus=%s"
        print(campus)
        ans_list = self.query.run(sql, campus)
        list = []
        for ans in ans_list:
            list += ans
        ans = "、".join(list)
        res = campus + "的食堂有：" + ans + "~"
        return res

    # Question 3 - 某食堂的人均
    def get_cost_res(self):
        restaurant = self.get_name("rr")
        sql = "select cost from restaurant where name=%s"
        ans = self.query.run(sql, restaurant)[0][0]
        res = restaurant +"人均"+ans+"元~"
        return res

    # Question 4 -  某个食堂评分
    def get_score_res(self):
        restaurant = self.get_name("rr")
        sql = "select score from restaurant where name=%s"
        ans = self.query.run(sql, restaurant)[0][0]
        res = restaurant + "的评分是: " + ans + "~"
        return res

        # Question 5 - 某个校区的味道不错的菜

    def get_gooddisk_campus(self):
        results = []
        campus = self.get_name("ut")
        sql = "select dish.name from dish,restaurant where campus=%s and dish.rid=restaurant.rid"
        dishes = self.query.run(sql, campus)
        for dish in dishes:
            a = ''.join(dish)
            sql = "select review from dish where name=%s"
            r = self.query.run(sql, a)[0]
            r = ''.join(r)
            score = sentiment.classify(r)
            if score >= 0.5:
                print(a, score)
                results.append(a)

        if len(results) == 0:
            return "该校区目前没有推荐菜"
        else:
            res = "、".join(results)

        ret = campus + "评价不错的菜有：" + res + "等～"
        return ret

    # Question 6 - 某个食堂的味道不错的菜
    def get_gooddisk_res(self):
        results = []
        restaurant = self.get_name("rr")
        sql = "select dish.name from dish,restaurant where restaurant.name=%s and dish.rid=restaurant.rid"
        dishes = self.query.run(sql, restaurant)
        for dish in dishes:
            a = ''.join(dish)
            sql = "select review from dish where name=%s"
            r = self.query.run(sql, a)[0]
            r = ''.join(r)
            score = sentiment.classify(r)
            if score >= 0.5:
                print(a, score)
                results.append(a)

        if len(results) == 0:
            return "该食堂目前没有推荐菜"
        else:
            res = "、".join(results)

        ret = restaurant + "评价不错的菜有：" + res + "等～"
        return ret

        # Question 7 - 某菜系有什么菜

    def get_dish_type(self):
        type = self.get_name("sst")
        sql = "select dish.name, restaurant.name from dish,restaurant where type=%s and dish.rid=restaurant.rid"
        ans = self.query.run(sql, type)
        list = ''
        for a in ans:
            l = a[0] + "在" + a[1] + "可以吃到"
            list += " | " + l
        res = type + ":"+list
        return res