#include "nemu.h"
#include<stdlib.h>

/* We use the POSIX regex functions to process regular expressions.
 * Type 'man regex' for more information about POSIX regex functions.
 */
#include <sys/types.h>
#include <regex.h>  // for c languare, regularized expressions
uint32_t isa_reg_str2val(const char *s, bool *success);
enum {
  TK_NOTYPE = 256, TK_EQ=257, TK_OR=258, TK_AND=259, TK_NUMBER=10, TK_HNUMBER=16, TK_UEQ=0, TK_REG=255, TK_POINTER=1, TK_NEG=2
  /* TODO: Add more token types */

};

static struct rule {
  char *regex;
  int token_type;
} rules[] = {

  /* TODO: Add more rules.
   * Pay attention to the precedence level of different rules.
   */
	{" +", TK_NOTYPE},    // spaces
	{"0[xX][0-9a-fA-F]+", TK_HNUMBER},
	{"[0-9]+", TK_NUMBER},
  {"\\+", '+'},
  {"-", '-'},//substract or neg
  {"\\*", '*'},
  {"/", '/'},
  {"\\(", '('},
  {"\\)", ')'},
  {"==", TK_EQ},         // equal
  {"!=", TK_UEQ},
  {"!", '!'},
  {"&&", TK_AND},
  {"\\|\\|", TK_OR},
  {"\\$[a-ehilpxc]{2,3}", TK_REG}
};

#define NR_REGEX (sizeof(rules) / sizeof(rules[0]) )

static regex_t re[NR_REGEX] = {}; // regex_t store number of regexs

/* Rules are used for many times.
 * Therefore we compile them only once before any usage.
 */
void init_regex() {
  int i;
  char error_msg[128];
  int ret;

  for (i = 0; i < NR_REGEX; i ++) {
    ret = regcomp(&re[i], rules[i].regex, REG_EXTENDED);
    // regcomp(regex_t *preg, const char * regex, int cflags)，description of function regcomp
    if (ret != 0) {
      regerror(ret, &re[i], error_msg, 128);
      panic("regex compilation failed: %s\n%s", error_msg, rules[i].regex);
    }
  }
}

typedef struct token {
  int type;
  char str[32];
} Token;

static Token tokens[256] __attribute__((used)) = {};
static int nr_token __attribute__((used))  = 0;

static bool make_token(char *e) {
  int position = 0;
  int i;
  regmatch_t pmatch;

  nr_token = 0; // number of regex tokens

  while (e[position] != '\0') {
    /* Try all rules one by one. */
    for (i = 0; i < NR_REGEX; i ++) {
      if (regexec(&re[i], e + position, 1, &pmatch, 0) == 0 && pmatch.rm_so == 0) {
        char *substr_start = e + position;
        int substr_len = pmatch.rm_eo;

        Log("match rules[%d] = \"%s\" at position %d with len %d: %.*s",
            i, rules[i].regex, position, substr_len, substr_len, substr_start);
        position += substr_len;

        /* TODO: Now a new token is recognized with rules[i]. Add codes
         * to record the token in the array `tokens'. For certain types
         * of tokens, some extra actions should be performed.
         */
		switch(rules[i].token_type){
			case TK_NOTYPE: break;	//空格跳过
			case TK_REG:
				tokens[nr_token].type=rules[i].token_type;
				strncpy(tokens[nr_token].str, substr_start+1, substr_len-1);
				tokens[nr_token].str[substr_len-1]=0;
				nr_token++;
				break;
			case '-':case '*':
				if(nr_token==0||(tokens[nr_token-1].type!=TK_NUMBER&&tokens[nr_token-1].type!=TK_HNUMBER&&tokens[nr_token-1].type!=TK_REG&&tokens[nr_token-1].type!=')')){
					if(rules[i].token_type=='-'){
							tokens[nr_token].type=TK_NEG;
					}
					else tokens[nr_token].type=TK_POINTER;
				}
				else tokens[nr_token].type=rules[i].token_type;
				strncpy(tokens[nr_token].str, substr_start, substr_len);
				tokens[nr_token].str[substr_len]=0;
				nr_token++;
				break;
			default:
				tokens[nr_token].type=rules[i].token_type;
				strncpy(tokens[nr_token].str, substr_start, substr_len);
				tokens[nr_token].str[substr_len]=0;
				nr_token++;
		}
    }
    if (i == NR_REGEX) {
      printf("no match at position %d\n%s\n%*.s^\n", position, e, position, "");
      return false;
    }
  }
 }
  return true;
}

int priority(int type){
	switch(type){
		case TK_NUMBER:case TK_HNUMBER:case TK_REG: case TK_NOTYPE:return 0;
		case TK_OR:return 1;
		case TK_AND:return 2;
		case TK_EQ:case TK_UEQ:return 3;
		case '-':case '+':return 4;
		case '/':case '*':return 5;
		case TK_POINTER:return 6;
		case '!':case TK_NEG:return 7;
		case '(':case ')':return 8;
		default: return 0;
	}
}


bool check_parentheses(int l, int r){
	if(tokens[l].type=='('&&tokens[r].type==')'){
		int lc=0;
		int rc=0;
		for(int i=l+1;i<r;i++){
			if(tokens[i].type=='(') lc++;
			else if(tokens[i].type==')') rc++;
			if(lc<rc){
				return false; 
			}
		}
		if(lc==rc) return true;
	}
	return false;
}

int dominant_operator(int l, int r){
	int dom=l;
	int p=0;
	int m_p=8;
	for(int i=l;i<=r;i++){
		if(tokens[i].type==TK_NUMBER||tokens[i].type==TK_HNUMBER||tokens[i].type==TK_REG) continue;
		if(tokens[i].type=='('){
			int lc=1;
			while(lc&&i<r){
				i++;
				if(tokens[i].type=='(') lc++;
				else if(tokens[i].type==')') lc--;
			}
			if(lc==0) continue;
			else return -1;
		}
		p=priority(tokens[i].type);
		if(p<=m_p){
			m_p=p;
			dom=i;	
		}
	}
		return dom;
	}

uint32_t eval(int l, int r) {
  if (l > r) {
    Log("please check you expression\n"); // 这里展示Log函数的使用方法
    assert(0);                            // 这里展示assert函数的使用方法
    /* Bad expression */
  }
  
  while(l<r&&check_parentheses(l, r)==true){
  	l++;
  	r--;
  }
  if (l == r) {
    /* Single token.
     * For now this token should be a number.
     * Return the value of the number.
     */
     int n=0;
     if(tokens[r].type==TK_NUMBER){
     		sscanf(tokens[r].str, "%d", &n);
     		return n;
     	}
     else if(tokens[r].type==TK_HNUMBER){
     	sscanf(tokens[r].str, "%x", &n);
			return n;
			}
			else if(tokens[r].type==TK_REG){
			bool success=true;
			n=isa_reg_str2val(tokens[r].str, &success);
			if(!success){
				printf("No such register\n");
				assert(0);
			}
			return n;
			}
    }
  
  else {
    /* We should do more things here. */
    int op=dominant_operator(l, r);
		if(op==-1) {
			Log("please check you expression\n"); 
   	  assert(0);  		
		}
		printf("\033[1m\033[33m[mainop]\033[0m ");
		printf(": %d:%s\n", op, tokens[op].str);
		if(tokens[op].type==TK_POINTER||tokens[op].type==TK_NEG||tokens[op].type=='!'){
			uint32_t val=eval(l+1, r);
			switch(tokens[l].type){
				case TK_NEG: return -val;
				case TK_POINTER: return paddr_read(val, 4);
				case '!': return !val;
				default:assert(0);
			
			}
		}
		
    int left=eval(l, op-1);
    int right=eval(op+1, r);
    switch(tokens[op].type){
    	case '+': return left+right;
    	case '-': return left-right;
    	case '*': return left*right;
    	case '/': return left/right;
    	case TK_EQ: return left==right;
    	case TK_UEQ: return left!=right;
    	case TK_AND: return left&&right;
    	case TK_OR: return left||right;
    	default: assert(0);
	}
  }
  return 0;
}


uint32_t expr(char *e, bool *success) {
  if (!make_token(e)) {
    *success = false;
  }
	
  /* TODO: Insert codes to evaluate the expression. */
  int l=0, r=nr_token-1;
  return eval(l, r);
}

    
