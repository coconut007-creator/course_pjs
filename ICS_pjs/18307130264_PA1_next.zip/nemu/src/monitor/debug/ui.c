#include "monitor/monitor.h"
#include "monitor/expr.h"
#include "monitor/watchpoint.h"
#include "nemu.h"
#include<dirent.h> // for c language, file directory operations (use 'man opendir' for more information)
#include<unistd.h> // for c language, get work path (use 'man getcwd' for more information)
#include <stdlib.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <sys/stat.h>

static int cmd_pwd(char *);
static int cmd_echo(char *); // define functions 

void cpu_exec(uint64_t);
void isa_reg_display();
/* We use the `readline' library to provide more flexibility to read from stdin. */
static char* rl_gets() {
  static char *line_read = NULL;

  if (line_read) {
    free(line_read);
    line_read = NULL;
  }

  line_read = readline("(nemu) ");

  if (line_read && *line_read) {
    add_history(line_read);
  }

  return line_read;
}

static int cmd_c(char *args) {
  cpu_exec(-1);
  return 0;
}

static int cmd_q(char *args) {
  return -1;
}

static int cmd_si(char *args){
	int n;
	if(!args) n=1;
	else sscanf(args,"%d",&n);
	cpu_exec(n);
	printf("execute for %d steps finished\n", n);
  return 0;
}

static int cmd_info(char* args){
	char str2[]="pc";
	if(args==NULL){
		printf("too few argument\n");
		return 0;
	}
	
	if(strcmp(args, "r")==0){
		isa_reg_display();
		return 0;
	}
	else if(strcmp(args, "w")==0){
		print_wp();
		return 0;
	}
	else if(strcmp(args, str2) == 0)
	{
		printf("\033[1m\033[33m[pc] \033[0m: address: 0x%08x, value: 0x%08x\n", cpu.pc, paddr_read(cpu.pc, 4));
		return 0;
	}
	else {
		printf("Can't find the command\n");
		return 0;
	}
}

static int cmd_w(char *args){
	WP* p;
	bool suc=true;
	int val=expr(args, &suc);
	if(!suc){
		printf("wrong expression");
		assert(0);
	}
	p=new_wp(args, val);
	printf("Watchpoint %d:		expr:%s		val:0x%x\n", p->NO, p->msg, p->val);
	return 0;
}

static int cmd_d_w(char *args){
	int n;
	if(!args){
		delete_all_wp();
		return 0;
	}
	sscanf(args, "%d", &n);
	free_wp(n);
	return 0;
}

static int cmd_ls(char *args){
	char *arg = strtok(NULL, " ");
	char buf[256];
  if (arg == NULL){
  	if(getcwd(buf, 256)!=0){}//present path
	}
	else strcpy(buf, arg);
	printf("list the files in path:%s\n", buf);
 	DIR* dirp=opendir(buf);
	if(!dirp){
		printf("Error open\n");
		return -1;
	}
 	struct dirent *dir;
 	while((dir=readdir(dirp))!=NULL){
		if(dir->d_type==4){
			printf("\033[1m\033[34m %s \033[0m ", dir->d_name);
		}
		else printf("%s  ", dir->d_name);
	}
	printf("\n");
	closedir(dirp);
	return 0;
}

static int cmd_p(char* args){
	int res;
	bool *success=NULL;
	res=expr(args, success);
	printf("Result is 0x%x in hex, is %d in dec\n", res, res);
	return 0;
}

static int cmd_x(char* args){
	char s[32];
	int k, length;
	int addr;
	bool* success=NULL;
	sscanf(args,"%d %s",&length, s);
	Log("number of (4 bytes) are %d\n", length);
	addr=expr(s, success);
	Log("the beginning address of scanning is 0x%08x\n",addr);
	for(k=0;k<length;k++){
		printf("0x%08x:  ", addr+4*k);
		for(int i=0;i<4;i++)
			printf("0x%02x  ",paddr_read((paddr_t)(addr+4*k+i),1));//memory.c
		printf("\n");
	}
	return 0;
}

static int cmd_help(char *args);

static struct {
  char *name;
  char *description;
  int (*handler) (char *);
} cmd_table [] = {
  { "help", "Display informations about all supported commands", cmd_help },
  { "c", "Continue the execution of the program", cmd_c},
  { "q", "Exit NEMU", cmd_q },
  /* TODO: Add more commands *
   * you should add more commands as described in our manual
   */
	{"si", "Execute for N steps, if N is not given, exec_once", cmd_si},
	{"info", "Print information of register and watchpoints", cmd_info},
	{"ls", "list all files in given path", cmd_ls},
	{"p", "Compute the value of an expression", cmd_p},
	{"x", "Scan Memory from start, for total N bytes", cmd_x},
  { "echo", "Print the characters given by user", cmd_echo}, // add by wuran
  { "pwd", "Print current work path", cmd_pwd}, // add by wuran
  {"w", "add a new watchpoint", cmd_w},
  {"d", "delete a watchpoint or all watchpoints", cmd_d_w}
};

#define NR_CMD (sizeof(cmd_table) / sizeof(cmd_table[0])) // number of commands

static int cmd_help(char *args) {
  /* extract the first argument */
  char *arg = strtok(NULL, " ");
  int i;

  if (arg == NULL) {
    /* no argument given */
    for (i = 0; i < NR_CMD; i ++) {
      printf("\033[1m\033[33m [%s]\033[0m - %s\n", cmd_table[i].name, cmd_table[i].description);
    }
  }
  else {
    for (i = 0; i < NR_CMD; i ++) {
      if (strcmp(arg, cmd_table[i].name) == 0) {
        printf("\033[1m\033[33m [%s]\033[0m - %s\n", cmd_table[i].name, cmd_table[i].description);
        return 0;
      }
    }
    printf("Unknown command '%s'\n", arg);
  }
  return 0;
}

static int cmd_echo(char *args){
  // char * arg = strtok(args, " ");
  if(args != NULL)
    printf("%s\n", args);
  else printf("\n");
  return 0;
}

static int cmd_pwd(char * args){
  char buf[256];
  if(getcwd(buf, 256) != 0)
    printf("current work path: %s\n", buf);
  return 0;
}

void ui_mainloop(int is_batch_mode) {
  if (is_batch_mode) {
    cmd_c(NULL);
    return;
  }

  for (char *str; (str = rl_gets()) != NULL; ) {
    char *str_end = str + strlen(str);

    /* extract the first token as the command */
    char *cmd = strtok(str, " ");
    if (cmd == NULL) { continue; }

    /* treat the remaining string as the arguments,
     * which may need further parsing
     */
    char *args = cmd + strlen(cmd) + 1;
    if (args >= str_end) {
      args = NULL;
    }

#ifdef HAS_IOE
    extern void sdl_clear_event_queue(void);
    sdl_clear_event_queue();
#endif

    int i;
    for (i = 0; i < NR_CMD; i ++) {
      if (strcmp(cmd, cmd_table[i].name) == 0) {
        if (cmd_table[i].handler(args) < 0) { return; }
        break;
      }
    }

    if (i == NR_CMD) { printf("Unknown command '%s'\n", cmd); }
  }
}
