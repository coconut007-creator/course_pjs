#include "monitor/watchpoint.h"
#include "monitor/expr.h"

#define NR_WP 32

static WP wp_pool[NR_WP] = {}; 

// TODO: try to re-organize, you can abort head and free_ pointer while just use static int index
static WP *head, *free_ = NULL;

void init_wp_pool() {
  int i;
  for (i = 0; i < NR_WP; i ++) {
    wp_pool[i].NO = i+1;
    wp_pool[i].next = &wp_pool[i + 1];
  }
  wp_pool[NR_WP - 1].next = NULL;
  head = NULL;
  free_ = wp_pool;
}

/* TODO: Implement the functionality of watchpoint */
WP* new_wp(char * msg, int val){
	if(free_==NULL) assert(0);
	WP *f, *p;
	f=free_;
	free_=free_->next;
	f->next=NULL;
	strcpy(f->msg, msg);
	f->val=val;
	p=head;
	if(p==NULL){
		head=f;
		p=head;
	}
	else{
		while(p->next!=NULL){
			p=p->next;
		}
		p->next=f;
	}
  return f;
}

void free_wp(int no){
	WP *p=head;
	if(head==NULL){
		printf("No watchpoints\n");
		return;
	}
	if(head->NO==no){
		head=head->next;
		p->next=free_;
		free_=p;
		printf("delete watchpoint %d\n", no);
		return;
	}
	else{
		while(p->next!=NULL&&p->next->NO!=no)
			p=p->next;
		if(p->next!=NULL&&p->next->NO==no){
			WP* f=p->next;
			p->next=p->next->next;
			f->next=free_;
			free_=f;
			printf("delete watchpoint %d\n", no);
		}
		else{
			printf("No such watchpoint, numbered as %d\n", no);
		}
	}
  return;
}

void print_wp(){
  WP *f;
  f=head;
  if(!f)
  	printf("No watchpoint\n");
  while(f){
  	printf(" %d watchpoint  expr:%s  val:  0x%x\n", f->NO, f->msg, f->val);
  	f=f->next;
  }
  return;
}

void delete_all_wp(){
	WP *f=head;
	while(f->next){
		f=f->next;
	}
	f->next=free_;
	head=NULL;
	return;
 
}

int check_wp(){
	WP* p=head;
	bool suc=true;
	int flag=0;
	while(p){
		p->new_val=expr(p->msg, &suc);
		if(!suc){
			printf("wrong expression\n");
		}
		else if(p->new_val!=p->val){
			flag=1;
			printf("Watchpoint %d:%s\n", p->NO, p->msg);
			printf("Old value= 0x%08x\n", p->val);
			printf("New value= 0x%08x\n", p->new_val);
			p->val=p->new_val;
		}
		p=p->next;
	}
	return flag;
}
