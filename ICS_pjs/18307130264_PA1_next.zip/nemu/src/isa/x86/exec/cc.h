#ifndef __CC_H__
#define __CC_H__

static inline const char* get_cc_name(int subcode) {
  static const char *cc_name[] = {
    "o", "no", "b", "nb",
    "e", "ne", "be", "nbe",
    "s", "ns", "p", "np",
    "l", "nl", "le", "nle"
  };
  return cc_name[subcode];
}

void rtl_setcc(rtlreg_t*, uint8_t);

#endif
