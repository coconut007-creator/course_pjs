#ifndef __RISCV32_DIFF_TEST_H__
#define __RISCV32_DIFF_TEST_H__

#define DIFFTEST_REG_SIZE (sizeof(uint32_t) * 33) // GRPs + pc

#endif
