void init_isa(void) {
}
