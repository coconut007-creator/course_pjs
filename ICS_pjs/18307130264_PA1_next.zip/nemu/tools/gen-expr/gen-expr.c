#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>
#include <string.h>

// this should be enough
static char buf[65536]="";

// TODO: implement these functions: choose, gen_rand_op, gen_num, gen_rand_expr
int a=0;
static inline uint32_t choose(uint32_t n) {
	uint32_t res=rand()%n;
  return res;
}

static inline void gen_rand_op(){
	int res=choose(8);
	switch(res){
		case 0:buf[a++]='+';break;
		case 1:buf[a++]='-';break;
		case 2:buf[a++]='*';break;
		case 3:buf[a++]='/';break;
		case 4:buf[a++]='&';buf[a++]='&';break;
		case 5:buf[a++]='|';buf[a++]='|';break;
		case 6:buf[a++]='=';buf[a++]='=';break;
		case 7:buf[a++]='!';buf[a++]='=';break;
	}
  return;
}

static inline void gen_num(){
	int c=rand()%2;
	switch(c){
		case 0: if(buf[a-1]=='/')buf[a++]=rand()%9+1+'0';
						else buf[a++]=rand()%10+'0';
						break;
		case 1: buf[a++]=rand()%9+1+'0';buf[a++]=rand()%10+'0';break;
	}
  return;
}

static inline void gen_rand_expr() {
  int i, j, k;
  uint32_t num=5;
  switch(choose(num)){ // choose(num)表达式随机取一个数字对num取模
    case 0:
      //gen_blank(); // 生成随机空格
      buf[a++]=' ';
      gen_rand_expr(); // 空格+表达式是表达式
      break;
    case 1:
      gen_num(); // 生成随机数字
      break; // 数字是表达式
    case 2:
      gen_rand_expr(); 
      gen_rand_op(); // 产生随机操作符
      if(buf[a-1]=='/'){
      	gen_num();
      }
      else
        gen_rand_expr(); // <expr> "op" <expr>是表达式
      break;
    case 3:
      i=a;
      buf[a++]='(';
      gen_rand_expr();
      j=a;
      buf[a++]=')';
      k=0;
      for(i=i+1;i<j;i++){
				if(buf[i]!=' '){
					k=1;
					break;
				}
			}
			if(!k){
				buf[j-1]='0';
			}
      //gen_right_expr(); // "(" <expr> ")"也是表达式
      break;
    case 4:
      /* generate expression for unary operator, such as "!"
       */
       if(a==0||a!=0&&buf[a-1]!=')'&&buf[a-1]!='0'&&buf[a-1]!='1'&&buf[a-1]!='2'&&buf[a-1]!='3'&&buf[a-1]!='4'&&buf[a-1]!='5'&&buf[a-1]!='6'&&buf[a-1]!='7'&&buf[a-1]!='8'&&buf[a-1]!='9'){
       	buf[a++]='!';
       	gen_rand_expr();
       }
     break;
      /* handle other cases if needed */
   }
}
// TODO: if necessary, try to re-implement main function for better generation of expression


static char code_buf[65536];
static char *code_format =
"#include <stdio.h>\n"
"int main() { "
"  unsigned result = %s; "
"  printf(\"%%u\", result); "
"  return 0; "
"}";

int main(int argc, char *argv[]) {
  int seed = time(0);
  srand(seed);
  int loop = 1;
  if (argc > 1) {
    sscanf(argv[1], "%d", &loop);
  }
  int i;
  for (i = 0;  i < loop; i ++) {
    buf[0]='\0';
    a=0;
	  gen_rand_expr();
	  buf[a] = 0;
    sprintf(code_buf, code_format, buf);

    FILE *fp = fopen("/tmp/.code.c", "w");
    assert(fp != NULL);
    fputs(code_buf, fp);
    fclose(fp);

    int ret = system("gcc /tmp/.code.c -o /tmp/.expr");
    if (ret != 0) continue;

    fp = popen("/tmp/.expr", "r");
    assert(fp != NULL);

    int result;
    fscanf(fp, "%d", &result);
    pclose(fp);

    printf("%u %s\n", result, buf);
  }
  return 0;
}


